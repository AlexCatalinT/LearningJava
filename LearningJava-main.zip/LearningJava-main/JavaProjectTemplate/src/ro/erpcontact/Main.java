package ro.erpcontact;

import ro.erpcontact.view.Console;

public class Main {

	public static void main(String[] args) throws Exception {
		Console ui = new Console();
		try {
			ui.run();
		}catch(Exception e) {	
		}
	}

}