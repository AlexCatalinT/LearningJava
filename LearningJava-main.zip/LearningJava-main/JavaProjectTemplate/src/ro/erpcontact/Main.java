package ro.erpcontact;

import ro.erpcontact.model.Bancnota;
import ro.erpcontact.model.IPortofel;
import ro.erpcontact.model.Portofel;
import ro.erpcontact.model.Unu;
import ro.erpcontact.view.Console;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static List<Bancnota> bancnote = new ArrayList<Bancnota>();
	public static Console ui;
	public static Portofel portofel;

	public static void main(String[] args) throws Exception {
//	bancnote.add(new Unu(1));
//	bancnote.add(new Unu(5));
	portofel = new Portofel(bancnote);
	ui = new Console(portofel);
		try {
			ui.run();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}