package ro.erpcontact.controller;

import ro.erpcontact.model.*;

public class ControllerPortofel {
    private Portofel portofel;

    public ControllerPortofel(Portofel p) {
        this.portofel = p;
    }

    public void puneBani(Integer valoare) {
        int val_aux = valoare;
        if (val_aux > 0 && sute(val_aux) > 0) {
            for (int i = 0; i < sute(val_aux); i++) {
                OSuta x = new OSuta(100);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 100!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = valoare - sute(valoare)*100;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if (val_aux > 0 && cincizeci(val_aux) > 0) {
            for (int i = 0; i < cincizeci(val_aux); i++) {
                Cincizeci x = new Cincizeci(50);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 50!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = val_aux - cincizeci(val_aux)*50;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if (val_aux > 0 && zeci(val_aux) > 0) {
            for (int i = 0; i < zeci(val_aux); i++) {
                Zece x = new Zece(10);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 10!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = val_aux - zeci(val_aux)*10;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if (val_aux > 0 && cinci(val_aux) > 0) {
            for (int i = 0; i < cinci(val_aux); i++) {
                Cinci x = new Cinci(5);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 5!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = val_aux - cinci(val_aux)*5;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if(val_aux > 0){
            for (int i = 0; i < val_aux; i++) {
                Unu x = new Unu(1);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 1!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
        }
    }

    public String sumaPortofel() {
        return "Ai suma totala de " + portofel.getSuma().toString();
    }

    public void extrageBani(Integer valoare) {
        int val_aux = valoare;
        if (val_aux > 0 && sute(val_aux) > 0) {
            for (int i = 0; i < sute(val_aux); i++) {
                OSuta x = new OSuta(100);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 100!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = valoare - sute(valoare)*100;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if (val_aux > 0 && cincizeci(val_aux) > 0) {
            for (int i = 0; i < cincizeci(val_aux); i++) {
                Cincizeci x = new Cincizeci(50);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 50!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = val_aux - cincizeci(val_aux)*50;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if (val_aux > 0 && zeci(val_aux) > 0) {
            for (int i = 0; i < zeci(val_aux); i++) {
                Zece x = new Zece(10);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 10!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = val_aux - zeci(val_aux)*10;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if (val_aux > 0 && cinci(val_aux) > 0) {
            for (int i = 0; i < cinci(val_aux); i++) {
                Cinci x = new Cinci(5);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 5!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
            val_aux = val_aux - cinci(val_aux)*5;
        } else {System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);}

        if(val_aux > 0){
            for (int i = 0; i < val_aux; i++) {
                Unu x = new Unu(1);
                if ("Am adaugat cu success!".equals(portofel.adaugaBancnota(x))) {
                    System.out.println("Am adaugat cu success 1!");
                } else {
                    System.out.println("Nu s-a putut adauga bancnota cu valoarea de: " + valoare);
                }
            }
        }
    }

    private int sute(int x) {
        if (x / 100 > 0) {
            return x / 100;
        }
        return 0;
    }

    private int cincizeci(int x) {
        if (x / 50 > 0) {
            return x / 50;
        }
        return 0;
    }

    private int zeci(int x) {
        if (x / 10 > 0) {
            return x / 10;
        }
        return 0;
    }

    private int cinci(int x) {
        if (x / 5 > 0) {
            return x / 5;
        }
        return 0;
    }
}
