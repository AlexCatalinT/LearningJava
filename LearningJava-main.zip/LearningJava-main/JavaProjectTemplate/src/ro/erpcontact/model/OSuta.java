package ro.erpcontact.model;

public class OSuta extends Bancnota{
    public OSuta(int x) {
        super();
        setValoare(x);
    }

    @Override
    public void setValoare(int val){
        super.setValoare(val);
    }

    @Override
    public int getValoare() {
        return super.getValoare();
    }
}
