package ro.erpcontact.model;

public class Cincizeci extends Bancnota{
    public Cincizeci(int x) {
        super();
        setValoare(x);
    }

    @Override
    public void setValoare(int val){
        super.setValoare(val);
    }

    @Override
    public int getValoare() {
        return super.getValoare();
    }
}
