package ro.erpcontact.model;

public abstract class Bancnota {
    private int valoare;

    public int getValoare() {
        return valoare;
    }

    public void setValoare(int valoare) {
        this.valoare = valoare;
    }
}
