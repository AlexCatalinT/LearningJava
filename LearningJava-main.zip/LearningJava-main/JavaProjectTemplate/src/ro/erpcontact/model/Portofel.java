package ro.erpcontact.model;

import java.util.List;

public class Portofel implements IPortofel {
    private List<Bancnota> bancnote;
    private Integer suma = new Integer(0);

    public Portofel(List<Bancnota> bancnote) {
        this.bancnote = bancnote;
        calcSuma();
    }

    public Integer getSuma() { return suma; }

    public void setSuma(Integer suma) {
        this.suma = suma;
    }

    public void setBancnote(List<Bancnota> bancnote) {
        this.bancnote = bancnote;
    }

    private void calcSuma(){
        setSuma(0);
        for (Bancnota b : bancnote){
            setSuma(suma+b.getValoare());
        }
    }

    @Override
    public String adaugaBancnota(Bancnota bancnota) {
        if (bancnota.getValoare() > 0) {
            bancnote.add(bancnota);
            calcSuma();
            return "Am adaugat cu success!";
        }
        return "Nu s-a putut adauga bancnota cu valoarea de: " + bancnota.getValoare();
    }

    @Override
    public String extageBancnota(Bancnota bancnota) {
        if (bancnota.getValoare() > 0) {
            bancnote.remove(bancnota);
            return "Am extras cu success!";
        }
        return "Nu s-a putut extrage bancnota cu valoarea de: " + bancnota.getValoare();
    }
}
