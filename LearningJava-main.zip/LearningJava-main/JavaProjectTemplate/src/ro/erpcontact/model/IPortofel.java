package ro.erpcontact.model;

import java.util.ArrayList;

public interface IPortofel {
    public String adaugaBancnota(Bancnota bancnota);
    public String extageBancnota(Bancnota bancnota);
}
