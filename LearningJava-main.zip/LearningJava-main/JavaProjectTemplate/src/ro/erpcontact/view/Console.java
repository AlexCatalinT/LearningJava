package ro.erpcontact.view;

import ro.erpcontact.controller.ControllerPortofel;
import ro.erpcontact.model.Portofel;

import java.util.Scanner;

public class Console {

    private Scanner scanner = new Scanner(System.in);
    private ControllerPortofel p;
    private Portofel portofel;

    public Console(Portofel portofel) {
        this.portofel = portofel;
    }

    private void showMenu() {
        System.out.println("1. Meniu1");
        System.out.println("2. Meniu2");
        System.out.println("x. Exit");
    }

    public void run() throws Exception {
        while (true) {
            showMenu();
            System.out.println("Choose an option:");
            String option = scanner.next();
            switch (option) {
                case "1":
                    runMeniu1();
                    break;
                case "2":
                    runMeniu2();
                    break;
                case "x":
                    return;
                default:
                    System.out.println("Invalid option!");
                    break;
            }
        }
    }

    private void runMeniu1() {
        while (true) {
            System.out.println("1. OP1 - Creaza Portofel");
            System.out.println("2. OP2 - Adauga bancnota in portofel");
            System.out.println("3. OP3 - Vezi ce suma ai");
            System.out.println("4. Back");

            System.out.println("Choose an option:");
            String option = scanner.next();
            switch (option) {
                case "1":
                    OP1();
                    System.out.println("OP1 - Portofel creat");
                    break;
                case "2":
                    System.out.println("OP2 - Adauga bancnota in portofel:");
                    System.out.println("Ce suma vrei sa adaugi in portofel:");
                    int aux = scanner.nextInt();
                    scanner.nextLine();
                    OP2(aux);
                    break;
                case "3":
                    System.out.println("OP3 - Vezi ce suma ai");
                    System.out.println(OP3());
                    break;
                case "4":
                    return;
                default:
                    System.out.println("Invalid option!");
                    break;
            }
        }
    }

    private String OP3() {
        return p.sumaPortofel();
    }

    private void OP2(int aux) {
        p.puneBani(aux);
    }

    private void OP1() {
        p = new ControllerPortofel(portofel);
    }

    private void runMeniu2() {
        while (true) {
            System.out.println("1. OP1");
            System.out.println("2. OP2");
            System.out.println("3. OP3");
            System.out.println("4. Back");

            System.out.println("Choose an option:");
            String option = scanner.next();
            switch (option) {
                case "1":
                    System.out.println("OP1");
                    break;
                case "2":
                    System.out.println("OP2");
                    break;
                case "3":
                    System.out.println("OP2");
                    break;
                case "4":
                    return;
                default:
                    System.out.println("Invalid option!");
                    break;
            }
        }
    }

}

