package ro.erpcontact.view;

import java.util.Scanner;

public class Console {

    private Scanner scanner = new Scanner(System.in);

    public Console() {

    }

    private void showMenu() {
        System.out.println("1. Meniu1");
        System.out.println("2. Meniu2");
        System.out.println("x. Exit");
    }

    public void run() throws Exception {
        while (true) {
            showMenu();
            System.out.println("Choose an option:");
            String option = scanner.next();
            switch (option) {
                case "1":
                    runMeniu1();
                    break;
                case "2":
                    runMeniu2();
                    break;
                case "x":
                    return;
                default:
                    System.out.println("Invalid option!");
                    break;
            }
        }
    }

    private void runMeniu1() {
        while (true) {
            System.out.println("1. OP1");
            System.out.println("2. OP2");
            System.out.println("3. OP3");
            System.out.println("4. Back");

            System.out.println("Choose an option:");
            String option = scanner.next();
            switch (option) {
                case "1":
                    System.out.println("OP1");
                    break;
                case "2":
                    System.out.println("OP2");
                    break;
                case "3":
                    System.out.println("OP2");
                    break;
                case "4":
                    return;
                default:
                    System.out.println("Invalid option!");
                    break;
            }
        }
    }
    
    private void runMeniu2() {
        while (true) {
            System.out.println("1. OP1");
            System.out.println("2. OP2");
            System.out.println("3. OP3");
            System.out.println("4. Back");

            System.out.println("Choose an option:");
            String option = scanner.next();
            switch (option) {
                case "1":
                    System.out.println("OP1");
                    break;
                case "2":
                    System.out.println("OP2");
                    break;
                case "3":
                    System.out.println("OP2");
                    break;
                case "4":
                    return;
                default:
                    System.out.println("Invalid option!");
                    break;
            }
        }
    }

}

